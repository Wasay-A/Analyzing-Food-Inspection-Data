(function($) {
  'use strict';

  // initializing inputmask
  $(":input").inputmask();

})(jQuery);